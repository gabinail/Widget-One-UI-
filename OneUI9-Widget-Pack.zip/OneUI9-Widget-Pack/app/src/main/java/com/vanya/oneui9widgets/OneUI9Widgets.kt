package com.vanya.oneui9widgets

import android.app.ActivityManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.widget.RemoteViews
import java.util.Calendar
import kotlin.random.Random

object WidgetHelper {
    const val ACTION_REFRESH = "com.vanya.oneui9widgets.ACTION_REFRESH"
    const val ACTION_NEXT_QUOTE = "com.vanya.oneui9widgets.ACTION_NEXT_QUOTE"

    private val quotes = listOf(
        "Истинное мастерство — когда код не тормозит, а кастом выглядит как сток.",
        "Силуэт в темноте не нуждается в лишних полигонах.",
        "KWGT — для терпеливых. Нативный код — для бессмертных.",
        "Ночной бриз, горячий чай и чистый билд без единого ворнинга.",
        "Даже тысячелетний маг ценит хороший менеджмент памяти.",
        "Стекло One UI 9 отражает только то, что ты сам позволишь увидеть."
    )

    fun getBatteryInfo(context: Context): Pair<Int, Float> {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: 100
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: 100
        val temp = (intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 300) ?: 300) / 10f
        val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else 100
        return Pair(pct, temp)
    }

    fun getRamInfo(context: Context): Triple<Long, Long, Int> {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val totalGb = mi.totalMem / (1024 * 1024 * 1024)
        val usedMem = mi.totalMem - mi.availMem
        val usedPct = ((usedMem.toDouble() / mi.totalMem.toDouble()) * 100).toInt()
        val usedGb = usedMem / (1024 * 1024 * 1024)
        return Triple(usedGb, totalGb, usedPct)
    }

    fun getStorageInfo(): Pair<Long, Long> {
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = (stat.blockCountLong * stat.blockSizeLong) / (1024 * 1024 * 1024)
        val free = (stat.availableBlocksLong * stat.blockSizeLong) / (1024 * 1024 * 1024)
        return Pair(total - free, total)
    }

    fun getUptime(): String {
        val hours = SystemClock.elapsedRealtime() / (1000 * 60 * 60)
        val mins = (SystemClock.elapsedRealtime() / (1000 * 60)) % 60
        return "${hours}ч ${mins}м"
    }

    fun refreshPendingIntent(context: Context, action: String = ACTION_REFRESH): PendingIntent {
        val intent = Intent(context, HubWidget::class.java).apply { this.action = action }
        return PendingIntent.getBroadcast(
            context, action.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun settingsPendingIntent(context: Context, settingsAction: String): PendingIntent {
        val intent = Intent(settingsAction).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
        return PendingIntent.getActivity(
            context, settingsAction.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun updateAllWidgets(context: Context) {
        val mgr = AppWidgetManager.getInstance(context)
        val (batPct, batTemp) = getBatteryInfo(context)
        val (usedGb, totalGb, ramPct) = getRamInfo(context)
        val (usedStorage, totalStorage) = getStorageInfo()
        val uptime = getUptime()

        mgr.getAppWidgetIds(ComponentName(context, HubWidget::class.java)).forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_hub)
            views.setTextViewText(R.id.tv_hub_battery, "⚡ $batPct%")
            views.setTextViewText(R.id.tv_hub_ram, "RAM: $ramPct% (${usedGb}/${totalGb}G)")
            views.setTextViewText(R.id.tv_hub_uptime, "UP: $uptime")
            views.setOnClickPendingIntent(R.id.widget_root, refreshPendingIntent(context))
            mgr.updateAppWidget(id, views)
        }

        mgr.getAppWidgetIds(ComponentName(context, ClockPillWidget::class.java)).forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_clock_pill)
            views.setOnClickPendingIntent(R.id.widget_root, settingsPendingIntent(context, Settings.ACTION_DATE_SETTINGS))
            mgr.updateAppWidget(id, views)
        }

        mgr.getAppWidgetIds(ComponentName(context, SysMonitorWidget::class.java)).forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_sys_monitor)
            views.setTextViewText(R.id.tv_sys_ram_detail, "ОЗУ: $usedGb ГБ / $totalGb ГБ ($ramPct%)")
            views.setTextViewText(R.id.tv_sys_storage, "Память: $usedStorage ГБ / $totalStorage ГБ")
            views.setTextViewText(R.id.tv_sys_temp, "Батарея: $batPct%  •  ${batTemp}°C")
            views.setOnClickPendingIntent(R.id.widget_root, refreshPendingIntent(context))
            mgr.updateAppWidget(id, views)
        }

        mgr.getAppWidgetIds(ComponentName(context, QuickDockWidget::class.java)).forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_quick_dock)
            views.setOnClickPendingIntent(R.id.btn_wifi, settingsPendingIntent(context, Settings.ACTION_WIFI_SETTINGS))
            views.setOnClickPendingIntent(R.id.btn_bt, settingsPendingIntent(context, Settings.ACTION_BLUETOOTH_SETTINGS))
            views.setOnClickPendingIntent(R.id.btn_battery_settings, settingsPendingIntent(context, Settings.ACTION_BATTERY_SAVER_SETTINGS))
            views.setOnClickPendingIntent(R.id.btn_refresh, refreshPendingIntent(context))
            mgr.updateAppWidget(id, views)
        }

        val quote = quotes[Random.nextInt(quotes.size)]
        mgr.getAppWidgetIds(ComponentName(context, ZenQuoteWidget::class.java)).forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_zen_quote)
            views.setTextViewText(R.id.tv_quote_body, quote)
            views.setOnClickPendingIntent(R.id.widget_root, refreshPendingIntent(context, ACTION_NEXT_QUOTE))
            mgr.updateAppWidget(id, views)
        }

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val phase = when (hour) {
            in 5..11 -> "🌅 РАССВЕТ ТЕНИ"
            in 12..17 -> "☀ ЗЕНИТ КЛИНКА"
            in 18..22 -> "🌇 СУМЕРКИ ИМПЕРИИ"
            else -> "🌙 НОЧНОЙ ДОЗОР"
        }
        mgr.getAppWidgetIds(ComponentName(context, ShadowDuskWidget::class.java)).forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_shadow_dusk)
            views.setTextViewText(R.id.tv_dusk_phase, phase)
            views.setTextViewText(R.id.tv_dusk_bat, "⚡ $batPct% • ${batTemp}°C")
            views.setTextViewText(R.id.tv_dusk_subtitle, "Аптайм: $uptime • ОЗУ: $ramPct%")
            views.setOnClickPendingIntent(R.id.widget_root, refreshPendingIntent(context))
            mgr.updateAppWidget(id, views)
        }
    }
}

open class BaseOneUI9Widget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetHelper.updateAllWidgets(context)
    }
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == WidgetHelper.ACTION_REFRESH || intent.action == WidgetHelper.ACTION_NEXT_QUOTE) {
            WidgetHelper.updateAllWidgets(context)
        }
    }
}

class HubWidget : BaseOneUI9Widget()
class ClockPillWidget : BaseOneUI9Widget()
class SysMonitorWidget : BaseOneUI9Widget()
class QuickDockWidget : BaseOneUI9Widget()
class ZenQuoteWidget : BaseOneUI9Widget()
class ShadowDuskWidget : BaseOneUI9Widget()
