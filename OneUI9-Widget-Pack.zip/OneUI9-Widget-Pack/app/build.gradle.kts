plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vanya.oneui9widgets"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vanya.oneui9widgets"
        minSdk = 28
        targetSdk = 34
        versionCode = 1
        versionName = "1.0-OneUI9"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
